<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Form submitted, process the data
  $name = $_POST["name"];
  $email = $_POST["email"];
  $phone = $_POST["phone"];
  $tour = $_POST["tour"];

  // Compose the email message
  $to = "abunyatop123@gmail.com";
  $subject = "New Tour Booking: $tour";
  $message = "Name: $name\n";
  $message .= "Email: $email\n";
  $message .= "Phone: $phone\n";
  $message .= "Selected Tour: $tour";

  // Additional headers
  $headers = "From: webmaster@example.com" . "\r\n" .
    "CC: somebodyelse@example.com";

  // Send the email
  $mailSent = mail($to, $subject, $message, $headers);

  // Check if the email was sent successfully
  if ($mailSent) {
    echo "Email sent successfully.";
  } else {
    echo "Email sending failed.";
  }
}

