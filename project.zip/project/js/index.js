var darkMode = false;

document.getElementById("theme-toggle").addEventListener("click", function() {
  darkMode = !darkMode;
  if (darkMode) {
    document.body.style.backgroundColor = "#333";
    document.body.style.color = "#fff";
  } else {
    document.body.style.backgroundColor = "#fff";
    document.body.style.color = "#000";
  }
});
